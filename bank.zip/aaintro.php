<html>
	<head>
		<title>GRIP</title>
		<link rel="stylesheet" href="style.css">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <style>
      h1{
        background-color: white;
        opacity: 0.6;
      }

      h2,b{
        color: white;
      }

      input[type=submit] {
width: 20%;
background-color: yellow;
color: black;
padding: 14px 20px;
margin: 8px 0;
border: none;
border-radius: 4px;
cursor: pointer;
font-size: 20;
}
    </style>
	</head>
	<body background="intro.jpg">
  <div class="topnav">
  <div class="topnav-right">
  <a class="active" href="index.php">Home</a>
  <a class="active" href="about.php">About Us</a>
  
</div>
</div>
<br><br><br>
<h1><big><center><marquee>Sparks Basic Banking System</marquee></center></big></h1>
<br><br>
<h2>&nbsp&nbspMoney transfer gets more Easier.</h2>
<h2>&nbsp&nbspFast | Reliable | Easy Transfer</h2>
<b>&nbsp&nbsp&nbsp&nbsp&nbsp&nbspAnn Zachariah</b><br>
&nbsp&nbsp&nbsp<a href="index.php"><input type="submit" name="submit" value="Get Started"></a>
</body>
</html>