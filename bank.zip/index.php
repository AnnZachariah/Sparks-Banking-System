<html>
	<head>
		<title>GRIP</title>
		<link rel="stylesheet" href="style.css">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
	</head>
	<body background="banks.jpg">
  <div class="topnav">
  <div class="topnav-right">
  <a class="active" href="index.php">Home</a>
  <a class="active" href="transferdetails.php">Transaction History</a>
  <a class="active" href="viewusers.php">Users</a>
  <a class="active" href="about.php">About Us</a>
</div>
</div>
<br><br><br>
<h1><big><center>Basic Banking System</center></big></h1>

<center>
<div class="container">
        <div class="button" >
        <img src="trans.png" height="150px" width="150px"><a href="transfer.php">Money Transfer
</a>
        </div><br>
  
        <div class="button" >
          <img src="user.jfif" height="150px" width="150px"><a href="viewusers.php">Transaction Details</a>
        </div>
  </div>
  
</center>
</body>
</html>