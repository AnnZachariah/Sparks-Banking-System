<html>
	<head>
		<title>GRIP</title>
		<link rel="stylesheet" href="style.css">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
	</head>
	<body background="banks.jpg">
  <div class="topnav">
  <div class="topnav-right">
  <a class="active" href="index.php">Home</a>
  <a class="active" href="transferdetails.php">Transaction History</a>
  <a class="active" href="viewusers.php">Users</a>
  <a class="active" href="about.php">About Us</a>
</div>
</div>
<br><br><br>
<div>
	<h3><p>
		Banking System ensures smooth operation of the Real-Estate management tasks as well as keep the information about the employees and their salary. 
	</p></h3>
	<center><img src="b.jfif" height="200px" width="300px"></center><br>
	
	<h4><p>
		-Our software will perform and fulfill all the tasks that any customer would desire.<br>
-Our motto is to develop a software program for managing the entire bank process related to customer accounts, employee accounts and to keep each every track about their property and their various transaction processes efficiently.<br>
-Hereby, our main objective is the customer’s satisfaction considering today’s faster world.

</p></h4>
<br><br>
<b><p>
Contact: 9273523163,
Email: abc123@gmail.com<br>
© GRIP 2021
</p>	</b>
</div>
</body>
</html>